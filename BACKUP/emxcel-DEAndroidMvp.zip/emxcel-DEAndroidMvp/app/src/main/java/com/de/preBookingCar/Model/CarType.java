package com.de.preBookingCar.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by AMD21 on 21/6/17.
 */

public class CarType {

    @SerializedName("carId")
    @Expose
    private Integer carId;
    @SerializedName("carName")
    @Expose
    private String carName;

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }
}
