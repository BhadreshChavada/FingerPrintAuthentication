package com.de.baseClass;

/**
 * Created by Bhadresh on 1/6/17.
 */

public interface basePresenter {


}
