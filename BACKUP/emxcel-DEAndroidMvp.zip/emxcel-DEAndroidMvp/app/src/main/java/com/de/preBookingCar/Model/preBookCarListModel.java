package com.de.preBookingCar.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class preBookCarListModel{


    @SerializedName("prebookigList")
    @Expose
    private List<PrebookigList> prebookigList = null;

    public List<PrebookigList> getPrebookigList() {
        return prebookigList;
    }

    public void setPrebookigList(List<PrebookigList> prebookigList) {
        this.prebookigList = prebookigList;
    }

}
