package com.de.baseClass;

import android.widget.TextView;

/**
 * Created by Bhadresh on 14/6/17.
 */

public interface baseDate {

    void onDateSelect(String date, TextView textView);
}
