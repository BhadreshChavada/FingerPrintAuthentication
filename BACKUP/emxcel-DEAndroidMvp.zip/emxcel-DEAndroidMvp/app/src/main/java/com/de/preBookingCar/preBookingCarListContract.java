package com.de.preBookingCar;

import com.de.baseClass.basePresenter;
import com.de.baseClass.baseView;
import com.de.data.APIResponse;

import java.util.HashMap;

/**
 * Created by AMD21 on 21/6/17.
 */

public interface preBookingCarListContract {

    interface view extends baseView<Presenter> {

        void setRecycleView();

    }

    interface Presenter extends basePresenter {

        void doGetPreBookingList(HashMap<String, String> map, APIResponse apiResponse);
    }
}
