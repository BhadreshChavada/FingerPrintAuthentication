package com.de.utils;

/**
 * Created by Bhadresh on 9/6/17.
 */

public class constantString {


    // TODO: 19/6/17 Local API service
    public static final String Loginjson = "/login.json";
    public static final String otpVerifyjson = "/verifyotp.json";
    public static final String getCarListjson = "/getcarlist.json";
    public static final String getUnassigneDriverlistjson = "/getunassigneddriverlist.json";
    public static final String updateCarDriverMappingjson = "/updatecardrivingmapping.json";
    public static final String bookCarListjson = "/bookedcarlist.json";
    public static final String updateTripDetailsjson = "/updatetripdetails.json";
    public static final String getCarTypejson = "/getcartype.json";
    public static final String searchCarjson = "/searchcar.json";
    public static final String paymentDatajson = "/paymentdata.json";
    public static final String cityListjson = "/citylist.json";
    public static final String bookCarjson = "/bookcar.json";
    public static final String preBookingjson = "/prebookcar.json";
    public static final String preBookingCarListjson = "/prebookinglist.json";

    // TODO: 19/6/17 Remote API Service
    public static final String LoginService = "/login/app/de-login-check";
    public static final String otpVerifyService = "/login/app/de-verify-otp";
    public static final String getCarListService = "/login/app/getCarList";
    public static final String getUnassigneDriverlistService = "/login/app/getUnassignedDriverList";
    public static final String updateCarDriverMappingService = "/login/app/updateCarDriverMapping";
    public static final String bookCarListService = "/login/app/bookedCarList";
    public static final String updateTripDetailsService = "/login/app/upateTripDetail";
    public static final String getCarTypeService = "/login/app/getCarType";
    public static final String searchCarService = "/login/app/searchCar";
    public static final String paymentDataService = "/login/app/getPaymentMode";
    public static final String cityListService = "/login/app/getCityList";
    public static final String bookCarService = "/login/app/bookCar";
    public static final String preBookingService = "/login/app/savePreBooking";
    public static final String preBookingCarListService = "/login/app/getPreBookingList";


    // TODO: 21/6/17 Other String
    public static String someThingWentWrong = "Something Went Wrong";
    public static String noInternet = "Please check the Internet Connection";
    public static String userToken = "userToken";
    public static String requestBooking = "RequestBooking";


    // TODO: 20/6/17 Validation Constant String
    public static String contactNoValidation = "Enter 10 Digit Contact no.";
    public static String passwordValidation = "Enter Password";
    public static String otpValidaion = "Enter OTP";
    public static String dateValidation = "Trip end date must be grater then trip start date.";
    public static String userValidaation = "UserName Can't be empty";
    public static String emailValidation = "Enter Valid EmailId";
    public static String locationValidation = "Enter  Location";
    public static String landmarkValidation = "Enter Laandmark";
    public static String hoursValidation = "Enter Hours";
    public static String kmsValidation = "Enter Kms";
    public static String amountValidation = "Enter Amount";
    public static String additionalChargeValidation = "Enter Additional Charges";
    public static String additionalKmValidation = "Enter Additional Kms";
    public static String rateValidation = "Enter Rate";
    public static String graceHourValidation = "Enter Grace Hours";
    public static String driverAllllownceValidation = "Please Enter Driver Allowance ";
    public static String sourcePlaceValidation = "Enter Source Place  ";
    public static String destinationPlaceValidation = "Enter Destination Place";
    public static String priceValidation = "Enter Price";
    public static String remarkValidation = "Enter Remark";


    // TODO: 13/6/17 Navigation Constant String
    public static String home = "Home";
    public static String bookCar = "Book Car";
    public static String listOfBookCar = "List of Booked Car";
    public static String bookingHistory = "Booking History";
    public static String preBookingCar = "Pre Booking Car";
    public static String listOfPreBookingCar = "List of Pre Booking Car";
    public static String preBooking = "Pre Booking";
    public static String carDriverMapping = "Car Driver Mapping";
    public static String expense = "Expense";
    public static String paymentManagement = "Payment Management";
    public static String account = "Account";
    public static String driver = "Driver";
    public static String customer = "Customer";
    public static String cancelRequest = "Cancel Request";
    public static String logout = "Logout";
    public static String driverCancelRequest = "Driver Cancel Request";
    public static String customerCancelRequest = "Customer Cancel Request";


    // TODO: 23/6/17 Sharedpreference Constant String
    public static String preference = "Preference";
    public static String userName = "UserName";
    public static String userId = "UserId";
    public static String fullName = "fullName";
    public static String contactNo = "contactNo";
    public static String emailId = "emailId";
    public static String avatar = "avatar";
    public static String userTenantId = "userTenantId";
    public static String token = "token";


}
