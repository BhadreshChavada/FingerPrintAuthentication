package com.de.preBookingCar;

import com.de.data.APIResponse;
import com.de.data.DERepository;

import java.util.HashMap;

/**
 * Created by AMD21 on 21/6/17.
 */

public class preBookingCarListPresenter implements preBookingCarListContract.Presenter {

    DERepository mDERepository;
    preBookingCarListContract.view mView;

    public preBookingCarListPresenter(DERepository mDERepository, preBookingCarListContract.view mView) {
        this.mDERepository = mDERepository;
        this.mView = mView;


        mView.setPresenter(this);
    }

    @Override
    public void doGetPreBookingList(HashMap<String, String> map, APIResponse apiResponse) {
        mDERepository.doPreBookingCarList(map, apiResponse);
    }
}
