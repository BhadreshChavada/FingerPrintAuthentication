package com.de.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by AMD21 on 22/6/17.
 */

public class sharedPreference {


    Context context;
    SharedPreferences preferences;

    public sharedPreference(Context context) {
        this.context = context;
        preferences = context.getSharedPreferences(constantString.preference, Context.MODE_PRIVATE);
    }

    public static sharedPreference getInstance(Context context) {
        return new sharedPreference(context);
    }

    public void saveSharedPreference(String key, String Value) {

        preferences.edit().putString(key, Value).commit();
    }

    public String getSharedPreferece(String key) {
        return preferences.getString(key, "");
    }

    public void clearSharedPreferece(String key){
        preferences.edit().remove(key).commit();
    }

    public void clearSharedPreferece(){
        preferences.edit().clear().commit();
    }
}
