package com.de.preBookingCar;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.de.R;
import com.de.baseClass.baseFragment;
import com.de.data.APIResponse;
import com.de.preBookingCar.Model.preBookCarListModel;

import java.util.HashMap;

import data.Injection;
import retrofit2.Call;
import retrofit2.Response;

import static com.google.gson.internal.$Gson$Preconditions.checkNotNull;

/**
 * Created by AMD21 on 21/6/17.
 */

public class preBookingCarListFragment extends baseFragment implements preBookingCarListContract.view {

    preBookingCarListContract.Presenter mPresenter;
    View mView;
    RecyclerView mRecycleView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.layout_recycleview, null);

        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();
        mPresenter = new preBookingCarListPresenter(Injection.provideDERepository(getActivity()), this);

        mRecycleView = (RecyclerView) mView.findViewById(R.id.layout_recycle_view);

        if (isNetworkAvailable()) {
            setRecycleView();
        }

    }

    @Override
    public void setPresenter(preBookingCarListContract.Presenter presenter) {
        mPresenter = checkNotNull(presenter);

    }

    @Override
    public void setLoadingIndicator(boolean active) {
        displayProgressDialog(active);
    }

    @Override
    public boolean isNetworkAvailable() {
        return isNetworkAvailable(getActivity());
    }

    @Override
    public void showToast(String message) {

    }

    @Override
    public void setRecycleView() {

        setLoadingIndicator(true);
        HashMap<String, String> map = new HashMap<>();

        mPresenter.doGetPreBookingList(map, new APIResponse<preBookCarListModel>() {
            @Override
            public void onSuccess(Call<preBookCarListModel> call, Response<preBookCarListModel> response) {
                setLoadingIndicator(false);
                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mRecycleView.setLayoutManager(mLayoutManager);
                mRecycleView.setItemAnimator(new DefaultItemAnimator());
                mRecycleView.setAdapter(new preBookCarListAdapter(response.body().getPrebookigList(), getActivity().getSupportFragmentManager(), getActivity()));

            }

            @Override
            public void onFailure(Call<preBookCarListModel> call, Throwable t) {

                setLoadingIndicator(false);
            }
        });
    }
}
