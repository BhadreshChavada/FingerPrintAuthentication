package com.de.data.local;


import com.de.bookCar.model.bookCarModel;
import com.de.bookCar.model.cityListModel;
import com.de.bookCar.model.paymentDataModel;
import com.de.bookCar.model.searchCarModel;
import com.de.bookCar.model.searchCarTypeModel;
import com.de.bookedCar.model.bookedCarModel;
import com.de.bookedCar.model.updateTripModel;
import com.de.carDriverMapping.model.carDriverMappingModel;
import com.de.carDriverMapping.model.driverListModel;
import com.de.carDriverMapping.model.updateCarDriverMappingModel;
import com.de.login.model.LoginModel;
import com.de.preBookingCar.Model.preBookCarListModel;
import com.de.preBookingCar.Model.preBookingModel;
import com.de.utils.constantString;
import com.de.verifyOtp.model.otpVerificationModel;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by Bhadresh on 6/6/17.
 */

public interface LocalAPIService {

    @GET(constantString.Loginjson)
    Call<LoginModel> getLoginCall();

    @GET(constantString.otpVerifyjson)
    Call<otpVerificationModel> getOtpVerificationCall();

    @GET(constantString.getCarListjson)
    Call<carDriverMappingModel> getCarList();

    @GET(constantString.getUnassigneDriverlistjson)
    Call<driverListModel> getDriverList();

    @GET(constantString.updateCarDriverMappingjson)
    Call<updateCarDriverMappingModel> AssignCaarDriverMapping();

    @GET(constantString.bookCarListjson)
    Call<bookedCarModel> getBookedCarList();

    @GET(constantString.updateTripDetailsjson)
    Call<updateTripModel> updateTrip();

    @GET(constantString.getCarTypejson)
    Call<searchCarTypeModel> getCarType();

    @GET(constantString.searchCarjson)
    Call<searchCarModel> getSearchCar();

    @GET(constantString.paymentDatajson)
    Call<paymentDataModel> getPaymentData();

    @GET(constantString.cityListjson)
    Call<cityListModel> getCityList();

    @GET(constantString.bookCarjson)
    Call<bookCarModel> getBookCarData();

    @GET(constantString.preBookingjson)
    Call<preBookingModel> getPreBookingCarData();

    @GET(constantString.preBookingCarListjson)
    Call<preBookCarListModel> getPreBookingCarList();
}
