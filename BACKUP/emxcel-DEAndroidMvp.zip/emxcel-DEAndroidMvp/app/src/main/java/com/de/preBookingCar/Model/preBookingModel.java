package com.de.preBookingCar.Model;

public class preBookingModel {
    private final String message;

    private final int preBookingid;

    public preBookingModel(String message, int preBookingid) {
        this.message = message;
        this.preBookingid = preBookingid;
    }

    public String getMessage() {
        return message;
    }

    public int getPreBookingid() {
        return preBookingid;
    }
}
