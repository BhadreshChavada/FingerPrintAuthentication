package com.de.bookCar;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.de.R;
import com.de.baseClass.baseFragment;
import com.de.baseClass.baseGooglePlacesAutocompleteAdapter;
import com.de.bookCar.model.CarList;
import com.de.bookCar.model.DriverList;
import com.de.bookCar.model.cityListModel;
import com.de.bookCar.model.paymentDataModel;
import com.de.carDriverMapping.carDriverMappingFragment;
import com.de.data.APIResponse;
import com.de.utils.constantString;
import com.de.utils.validationCheck;

import java.util.ArrayList;
import java.util.HashMap;

import data.Injection;
import retrofit2.Call;
import retrofit2.Response;

import static com.google.gson.internal.$Gson$Preconditions.checkNotNull;

/**
 * Created by Bhadresh on 15/6/17.
 */

public class bookCarInformation extends baseFragment implements bookCarInformationContract.View, View.OnClickListener {


    View mView;
    Button btnAutoInvoice, btnManualInvoice, btnBookNow, btnCancel;
    LinearLayout fragment_bookcar_linear;
    LinearLayout linearLayoutHoursAndKm, linearLayoutMinimumKm, linearLayoutSourcecDestination;
    TextView txtCarno, txtCarType, txtCarName, txtDriverName, txtPickupDateTime, txtDropDateTime;
    AutoCompleteTextView edtPickupLocation, edtDropLocation;
    Spinner spinnerAutomaticCity, spinnerAutomaticPayment, spinnerAutomaticInvoiceCategory, spinnerAutomaticRateContract;
    CheckBox checkBoxDebit;
    bookCarInformationContract.Presenter mPresenter;
    EditText edtPhoneNo, edtUserName, edtEmail, edtPickupLandmark, edtDropLandmark, edtHourandKmHours, edtHourandKmKms, edtHourandKmAmount, edtHourandKmAdditionalCharges, edtHourandKmAdditionalKmCharges, edtMinimumKmMinKm, edtMinimumKmMinRate, edtMinimumKmGraceHours, edtMinimumKmDriverAllownce, edtSourceToDestinationSourcePlace, edtSourceToDestinationDestionaationPlace, edtSourceToDestinationPrice, edtRemark;
    private View ViewHeader, viewAutoInvoie;
    private String fromDate, toDate;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mView = inflater.inflate(R.layout.fragment_bookcar_information, null);

        ViewHeader = inflater.inflate(R.layout.layout_bookcar_invoice_tab, null);
        viewAutoInvoie = inflater.inflate(R.layout.fragment_bookcarinformation_automatic_invoice, null);
        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();

        Bundle bundle = getArguments();
        ArrayList<CarList> carArray = bundle.getParcelableArrayList("carList");
        ArrayList<DriverList> driverArray = bundle.getParcelableArrayList("driverList");
        int carPosition = bundle.getInt("carPosition", 0);
        int driverPosition = bundle.getInt("driverPosition", 0);
        fromDate = bundle.getString("fromDate");
        toDate = bundle.getString("toDate");


        mPresenter = new bookCarInformationPresenter(Injection.provideDERepository(getActivity()), this);
        fragment_bookcar_linear = (LinearLayout) mView.findViewById(R.id.fragment_bookcar_linear);

        fragment_bookcar_linear.addView(ViewHeader, 0);
        fragment_bookcar_linear.addView(viewAutoInvoie, 1);
        btnAutoInvoice = (Button) ViewHeader.findViewById(R.id.invoice_tab_automatic);
        btnManualInvoice = (Button) ViewHeader.findViewById(R.id.invoice_tab_manual);
        btnBookNow = (Button) viewAutoInvoie.findViewById(R.id.btn_book_now);
        btnCancel = (Button) viewAutoInvoie.findViewById(R.id.btn_cancel);


        txtCarName = (TextView) viewAutoInvoie.findViewById(R.id.tv_car_name);
        txtCarType = (TextView) viewAutoInvoie.findViewById(R.id.tv_car_type);
        txtCarno = (TextView) viewAutoInvoie.findViewById(R.id.tv_car_number);
        txtCarno = (TextView) viewAutoInvoie.findViewById(R.id.tv_car_number);
        txtDriverName = (TextView) viewAutoInvoie.findViewById(R.id.tv_driver_name);
        txtPickupDateTime = (TextView) viewAutoInvoie.findViewById(R.id.txt_pickupdate_time);
        txtDropDateTime = (TextView) viewAutoInvoie.findViewById(R.id.txt_dropdate_time);

        edtPickupLocation = (AutoCompleteTextView) viewAutoInvoie.findViewById(R.id.et_pick_location);
        edtDropLocation = (AutoCompleteTextView) viewAutoInvoie.findViewById(R.id.et_drop_location);

        spinnerAutomaticCity = (Spinner) viewAutoInvoie.findViewById(R.id.sp_city);
        spinnerAutomaticPayment = (Spinner) viewAutoInvoie.findViewById(R.id.sp_payment);
        spinnerAutomaticInvoiceCategory = (Spinner) viewAutoInvoie.findViewById(R.id.sp_invoice_category);
        spinnerAutomaticRateContract = (Spinner) viewAutoInvoie.findViewById(R.id.sp_select_rate_contract);

        checkBoxDebit = (CheckBox) viewAutoInvoie.findViewById(R.id.checkbox_debits);

        edtPhoneNo = (EditText) viewAutoInvoie.findViewById(R.id.et_number);
        edtUserName = (EditText) viewAutoInvoie.findViewById(R.id.et__user_name);
        edtEmail = (EditText) viewAutoInvoie.findViewById(R.id.et_email);
        edtPickupLandmark = (EditText) viewAutoInvoie.findViewById(R.id.et_pickup_landmark);
        edtDropLandmark = (EditText) viewAutoInvoie.findViewById(R.id.et_drop_landmark);
        edtHourandKmHours = (EditText) viewAutoInvoie.findViewById(R.id.et_hourandkm_hr);
        edtHourandKmKms = (EditText) viewAutoInvoie.findViewById(R.id.et_hourandkm_kms);
        edtHourandKmAmount = (EditText) viewAutoInvoie.findViewById(R.id.et_hourandkm_amount);
        edtHourandKmAdditionalCharges = (EditText) viewAutoInvoie.findViewById(R.id.et_hourandkm_additionalacharges_hours);
        edtHourandKmAdditionalKmCharges = (EditText) viewAutoInvoie.findViewById(R.id.et_hourandkm_additionalkmcharges_hours);
        edtMinimumKmMinKm = (EditText) viewAutoInvoie.findViewById(R.id.et_minimumkm_minkm);
        edtMinimumKmMinRate = (EditText) viewAutoInvoie.findViewById(R.id.et_minimumkm_minrate);
        edtMinimumKmGraceHours = (EditText) viewAutoInvoie.findViewById(R.id.et_minimumkm_grace_hour);
        edtMinimumKmDriverAllownce = (EditText) viewAutoInvoie.findViewById(R.id.et_minimumkm_driver_allownce);
        edtSourceToDestinationSourcePlace = (EditText) viewAutoInvoie.findViewById(R.id.et_sourceanddestination_sourceplace);
        edtSourceToDestinationDestionaationPlace = (EditText) viewAutoInvoie.findViewById(R.id.et_sourceanddestination_destinationplace);
        edtSourceToDestinationPrice = (EditText) viewAutoInvoie.findViewById(R.id.et_sourceanddestination_price);
        edtRemark = (EditText) viewAutoInvoie.findViewById(R.id.et_remark);

        linearLayoutHoursAndKm = (LinearLayout) viewAutoInvoie.findViewById(R.id.rateandcontract_hourandkm);
        linearLayoutMinimumKm = (LinearLayout) viewAutoInvoie.findViewById(R.id.rateandcontract_minimumkm);
        linearLayoutSourcecDestination = (LinearLayout) viewAutoInvoie.findViewById(R.id.rateandcontract_sourceanddestination);

        linearLayoutSourcecDestination.setVisibility(View.GONE);
        linearLayoutMinimumKm.setVisibility(View.GONE);
        linearLayoutHoursAndKm.setVisibility(View.GONE);

        btnAutoInvoice.setOnClickListener(this);
        btnManualInvoice.setOnClickListener(this);
        btnBookNow.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        setGooglePlaceApi(edtPickupLocation);
        setGooglePlaceApi(edtDropLocation);

        txtCarno.setText(carArray.get(carPosition).getCarNumber());
        txtCarType.setText(carArray.get(carPosition).getCarType());
        txtCarName.setText(carArray.get(carPosition).getCarName());
        txtDriverName.setText(driverArray.get(driverPosition).getDriverName());
        txtPickupDateTime.setText(fromDate);
        txtDropDateTime.setText(toDate);


        if (isNetworkAvailable()) {
            getCity();
            getPaymentSpinnerData();
        }

        // TODO: 19/6/17 Set the Fiels as per the select Rate and Contract Spinner
        spinnerAutomaticRateContract.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    linearLayoutSourcecDestination.setVisibility(View.GONE);
                    linearLayoutMinimumKm.setVisibility(View.GONE);
                    linearLayoutHoursAndKm.setVisibility(View.VISIBLE);
                } else if (position == 1) {
                    linearLayoutSourcecDestination.setVisibility(View.GONE);
                    linearLayoutMinimumKm.setVisibility(View.VISIBLE);
                    linearLayoutHoursAndKm.setVisibility(View.GONE);
                } else if (position == 2) {
                    linearLayoutSourcecDestination.setVisibility(View.VISIBLE);
                    linearLayoutMinimumKm.setVisibility(View.GONE);
                    linearLayoutHoursAndKm.setVisibility(View.GONE);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    // TODO: 16/6/17 Get All Payment Spinner data and set Adapter
    private void getPaymentSpinnerData() {
        HashMap<String, String> map = new HashMap<String, String>();
        mPresenter.doGetPaymentData(map, new APIResponse<paymentDataModel>() {
            @Override
            public void onSuccess(Call<paymentDataModel> call, Response<paymentDataModel> response) {

                if (response.code() == 200) {

                    spinnerAutomaticRateContract.setAdapter(new rateOfContractSpinnerAdapter(getActivity(), R.layout.layout_spinner_backgroung, response.body().getRateOfContractList()));
                    spinnerAutomaticInvoiceCategory.setAdapter(new invoiceCategorySpinnerAdapter(getActivity(), R.layout.layout_spinner_backgroung, response.body().getInvoiceCategoryList()));
                    spinnerAutomaticPayment.setAdapter(new paymentTypeSpinnerAdapter(getActivity(), R.layout.layout_spinner_backgroung, response.body().getPaymentModeList()));


                }
            }

            @Override
            public void onFailure(Call<paymentDataModel> call, Throwable t) {

            }
        });
    }


    // TODO: 16/6/17 Get the city and set the spinner
    private void getCity() {
        HashMap<String, String> map = new HashMap<String, String>();

        mPresenter.doGetCity(map, new APIResponse<cityListModel>() {
            @Override
            public void onSuccess(Call<cityListModel> call, Response<cityListModel> response) {

                if (response.code() == 200) {
                    spinnerAutomaticCity.setAdapter(new citySpinnerAdapter(getActivity(), R.layout.layout_spinner_backgroung, response.body().getCityList()));

                }
            }

            @Override
            public void onFailure(Call<cityListModel> call, Throwable t) {

            }
        });

    }


    // TODO: 16/6/17 set Presenter
    @Override
    public void setPresenter(bookCarInformationContract.Presenter presenter) {
        mPresenter = checkNotNull(presenter);
    }

    // TODO: 16/6/17 set progress Dialog
    @Override
    public void setLoadingIndicator(boolean active) {

        displayProgressDialog(active);
    }

    @Override
    public boolean isNetworkAvailable() {
        return isNetworkAvailable(getActivity());
    }

    @Override
    public void showToast(String message) {

        displayToast(message);
    }


    // TODO: 19/6/17 Set the Field as per Automatic Invoice
    @Override
    public void setAutomaticInvoice() {

        btnAutoInvoice.setBackgroundResource(R.drawable.left_selected_tab);
        btnAutoInvoice.setTextColor(getResources().getColor(R.color.button_singup));
        btnManualInvoice.setBackgroundResource(R.drawable.right_unselected_tab);
        btnManualInvoice.setTextColor(getResources().getColor(R.color.white));

        spinnerAutomaticRateContract.setVisibility(View.VISIBLE);
        checkBoxDebit.setVisibility(View.GONE);


    }

    // TODO: 19/6/17 set the Field as per Manual Invoice
    @Override
    public void setManualInvoice() {

        btnManualInvoice.setBackgroundResource(R.drawable.right_selected_tab);
        btnManualInvoice.setTextColor(getResources().getColor(R.color.button_singup));
        btnAutoInvoice.setBackgroundResource(R.drawable.left_unselected_tab);
        btnAutoInvoice.setTextColor(getResources().getColor(R.color.white));

        spinnerAutomaticRateContract.setVisibility(View.GONE);
        checkBoxDebit.setVisibility(View.VISIBLE);

        linearLayoutSourcecDestination.setVisibility(View.GONE);
        linearLayoutMinimumKm.setVisibility(View.GONE);
        linearLayoutHoursAndKm.setVisibility(View.GONE);

    }

    @Override
    public boolean checkValidation() {


        if (edtPhoneNo.getText().toString().trim().length() != 10) {
            edtPhoneNo.setError(constantString.contactNoValidation);
            edtPhoneNo.requestFocus();
            return false;
        } else if (edtUserName.getText().toString().trim().length() == 0) {
            edtUserName.setError(constantString.userValidaation);
            edtUserName.requestFocus();
            return false;
        } else if (!validationCheck.checkEmail(edtEmail.getText().toString().trim().toString())) {
            edtEmail.setError(constantString.emailValidation);
            edtEmail.requestFocus();
            return false;
        } else if (edtPickupLocation.getText().toString().trim().length() == 0) {
            edtPickupLocation.setError(constantString.locationValidation);
            edtPickupLocation.requestFocus();
            return false;
        } else if (edtPickupLandmark.getText().toString().trim().length() == 0) {
            edtPickupLandmark.setError(constantString.landmarkValidation);
            edtPickupLandmark.requestFocus();
            return false;
        } else if (edtDropLandmark.getText().toString().trim().length() == 0) {
            edtDropLandmark.setError(constantString.landmarkValidation);
            edtDropLandmark.requestFocus();
            return false;
        } else if (edtDropLocation.getText().toString().trim().length() == 0) {
            edtDropLocation.setError(constantString.locationValidation);
            edtDropLocation.requestFocus();
            return false;
        } else if (spinnerAutomaticRateContract.getVisibility() == View.VISIBLE) {
            if (spinnerAutomaticRateContract.getSelectedItemPosition() == 0) {
                if (edtHourandKmHours.getText().toString().trim().length() == 0) {
                    edtHourandKmHours.setError(constantString.hoursValidation);
                    edtHourandKmHours.requestFocus();
                    return false;
                } else if (edtHourandKmKms.getText().toString().trim().length() == 0) {
                    edtHourandKmKms.setError(constantString.kmsValidation);
                    edtHourandKmKms.requestFocus();
                    return false;
                } else if (edtHourandKmAmount.getText().toString().trim().length() == 0) {
                    edtHourandKmAmount.setError(constantString.amountValidation);
                    edtHourandKmAmount.requestFocus();
                    return false;
                } else if (edtHourandKmAdditionalCharges.getText().toString().trim().length() == 0) {
                    edtHourandKmAdditionalCharges.setError(constantString.additionalChargeValidation);
                    edtHourandKmAdditionalCharges.requestFocus();
                    return false;
                } else if (edtHourandKmAdditionalKmCharges.getText().toString().trim().length() == 0) {
                    edtHourandKmAdditionalKmCharges.setError(constantString.additionalKmValidation);
                    edtHourandKmAdditionalKmCharges.requestFocus();
                    return false;
                }
                return true;
            } else if (spinnerAutomaticRateContract.getSelectedItemPosition() == 1) {
                if (edtMinimumKmMinKm.getText().toString().trim().length() == 0) {
                    edtMinimumKmMinKm.setError(constantString.kmsValidation);
                    edtMinimumKmMinKm.requestFocus();
                    return false;
                } else if (edtMinimumKmMinRate.getText().toString().trim().length() == 0) {
                    edtMinimumKmMinRate.setError(constantString.rateValidation);
                    edtMinimumKmMinRate.requestFocus();
                    return false;
                } else if (edtMinimumKmGraceHours.getText().toString().trim().length() == 0) {
                    edtMinimumKmGraceHours.setError(constantString.graceHourValidation);
                    edtMinimumKmGraceHours.requestFocus();
                    return false;
                } else if (edtMinimumKmDriverAllownce.getText().toString().trim().length() == 0) {
                    edtMinimumKmDriverAllownce.setError(constantString.driverAllllownceValidation);
                    edtMinimumKmDriverAllownce.requestFocus();
                    return false;
                }
                return true;
            } else if (spinnerAutomaticRateContract.getSelectedItemPosition() == 2) {
                if (edtSourceToDestinationSourcePlace.getText().toString().trim().length() == 0) {
                    edtSourceToDestinationSourcePlace.setError(constantString.sourcePlaceValidation);
                    edtSourceToDestinationSourcePlace.requestFocus();
                    return false;
                } else if (edtSourceToDestinationDestionaationPlace.getText().toString().trim().length() == 0) {
                    edtSourceToDestinationDestionaationPlace.setError(constantString.destinationPlaceValidation);
                    edtSourceToDestinationDestionaationPlace.requestFocus();
                    return false;
                } else if (edtSourceToDestinationPrice.getText().toString().trim().length() == 0) {
                    edtSourceToDestinationPrice.setError(constantString.priceValidation);
                    edtSourceToDestinationPrice.requestFocus();
                    return false;
                }
                return true;
            }
        } else if (edtRemark.getText().toString().trim().length() == 0) {
            edtRemark.setError(constantString.remarkValidation);
            edtRemark.requestFocus();
            return false;
        }

        return true;
    }


    // TODO: 19/6/17 Set the Google Place API
    @Override
    public void setGooglePlaceApi(AutoCompleteTextView autoCompleteTextView) {
        autoCompleteTextView.setAdapter(new baseGooglePlacesAutocompleteAdapter(getContext(), R.layout.layout_google_place));
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == btnAutoInvoice.getId()) {
            setAutomaticInvoice();
        } else if (v.getId() == btnManualInvoice.getId()) {
            setManualInvoice();
        } else if (v.getId() == btnBookNow.getId()) {
            if (isNetworkAvailable()) {
                if (checkValidation()) {
                    bookCarCall();
                }
            }


        } else if (v.getId() == btnCancel.getId()) {
            callFragment(new bookCarSearchFragment(), R.id.content_frame, "");
        }
    }

    private void bookCarCall() {
        HashMap<String, String> map = new HashMap<>();
        mPresenter.doBookCar(map, new APIResponse() {
            @Override
            public void onSuccess(Call call, Response response) {

                callFragment(new carDriverMappingFragment(), R.id.content_frame, "");
            }

            @Override
            public void onFailure(Call call, Throwable t) {

            }
        });
    }


}
