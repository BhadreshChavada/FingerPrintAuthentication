package com.de.preBookingCar.Model;

import com.de.carDriverMapping.model.CarType;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by AMD21 on 21/6/17.
 */

public class PrebookigList {

    @SerializedName("preBookingid")
    @Expose
    private Integer preBookingid;
    @SerializedName("requestDeviceType")
    @Expose
    private String requestDeviceType;
    @SerializedName("InvoiceType")
    @Expose
    private String invoiceType;
    @SerializedName("customerDetails")
    @Expose
    private CustomerDetails customerDetails;
    @SerializedName("carType")
    @Expose
    private CarType carType;
    @SerializedName("pickUpDateTime")
    @Expose
    private String pickUpDateTime;
    @SerializedName("pickUpLocation")
    @Expose
    private String pickUpLocation;
    @SerializedName("dropLocation")
    @Expose
    private String dropLocation;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("dropDateTime")
    @Expose
    private String dropDateTime;
    @SerializedName("paymentMode")
    @Expose
    private PaymentMode paymentMode;
    @SerializedName("preBookingId")
    @Expose
    private String preBookingId;

    public Integer getPreBookingid() {
        return preBookingid;
    }

    public void setPreBookingid(Integer preBookingid) {
        this.preBookingid = preBookingid;
    }

    public String getRequestDeviceType() {
        return requestDeviceType;
    }

    public void setRequestDeviceType(String requestDeviceType) {
        this.requestDeviceType = requestDeviceType;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public CustomerDetails getCustomerDetails() {
        return customerDetails;
    }

    public void setCustomerDetails(CustomerDetails customerDetails) {
        this.customerDetails = customerDetails;
    }

    public CarType getCarType() {
        return carType;
    }

    public void setCarType(CarType carType) {
        this.carType = carType;
    }

    public String getPickUpDateTime() {
        return pickUpDateTime;
    }

    public void setPickUpDateTime(String pickUpDateTime) {
        this.pickUpDateTime = pickUpDateTime;
    }

    public String getPickUpLocation() {
        return pickUpLocation;
    }

    public void setPickUpLocation(String pickUpLocation) {
        this.pickUpLocation = pickUpLocation;
    }

    public String getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(String dropLocation) {
        this.dropLocation = dropLocation;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDropDateTime() {
        return dropDateTime;
    }

    public void setDropDateTime(String dropDateTime) {
        this.dropDateTime = dropDateTime;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getPreBookingId() {
        return preBookingId;
    }

    public void setPreBookingId(String preBookingId) {
        this.preBookingId = preBookingId;
    }
}
