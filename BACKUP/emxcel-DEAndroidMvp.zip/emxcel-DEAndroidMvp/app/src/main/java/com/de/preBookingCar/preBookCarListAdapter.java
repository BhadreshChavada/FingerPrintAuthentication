package com.de.preBookingCar;

import android.content.Context;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.de.R;
import com.de.preBookingCar.Model.PrebookigList;

import java.util.List;

/**
 * Created by AMD21 on 21/6/17.
 */

class preBookCarListAdapter extends RecyclerView.Adapter<preBookCarListAdapter.ViewHolder> {

    List<PrebookigList> prebookigList;
    FragmentManager fm;
    Context context;

    public preBookCarListAdapter(List<PrebookigList> prebookigList, FragmentManager fm, Context context) {

        this.prebookigList = prebookigList;
        this.fm = fm;
        this.context = context;

    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_prebooking_list, parent, false);
        return new ViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.tvPreBookingId.setText(String.valueOf(prebookigList.get(position).getPreBookingId()));
        holder.getTvPreBookingUserMobileno.setText(prebookigList.get(position).getCustomerDetails().getCustomerMobile());
    }


    @Override
    public int getItemCount() {
        return prebookigList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvPreBookingId, getTvPreBookingUserMobileno;

        public ViewHolder(View itemView) {

            super(itemView);

            tvPreBookingId = (TextView) itemView.findViewById(R.id.tv_prebooking_id);
            getTvPreBookingUserMobileno = (TextView) itemView.findViewById(R.id.tv_prebooking_user_mobile_no);
        }
    }
}
