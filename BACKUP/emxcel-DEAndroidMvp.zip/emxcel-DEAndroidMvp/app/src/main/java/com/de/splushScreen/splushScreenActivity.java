package com.de.splushScreen;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;

import com.de.R;
import com.de.baseClass.baseActivity;
import com.de.login.loginActivity;
import com.de.navigationMenu.navigationActivity;
import com.de.utils.constantString;

/**
 * Created by AMD21 on 23/6/17.
 */

public class splushScreenActivity extends baseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splush_screen);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                String userID = getSharefpreference(constantString.userId);

                if (!userID.equals(null) || !userID.equals("")) {
                    callIntent(navigationActivity.class, "");
                } else {
                    callIntent(loginActivity.class, "");
                }

            }
        }, 2000);
    }
}
