package com.de.data.remote;

import com.de.bookCar.model.bookCarModel;
import com.de.bookCar.model.cityListModel;
import com.de.bookCar.model.paymentDataModel;
import com.de.bookCar.model.searchCarModel;
import com.de.bookCar.model.searchCarTypeModel;
import com.de.bookedCar.model.bookedCarModel;
import com.de.bookedCar.model.updateTripModel;
import com.de.carDriverMapping.model.carDriverMappingModel;
import com.de.carDriverMapping.model.driverListModel;
import com.de.carDriverMapping.model.updateCarDriverMappingModel;
import com.de.login.model.LoginModel;
import com.de.preBookingCar.Model.preBookCarListModel;
import com.de.preBookingCar.Model.preBookingModel;
import com.de.utils.constantString;
import com.de.verifyOtp.model.otpVerificationModel;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

/**
 * Created by Bhadresh on 15/4/17.
 */

public interface RemoteAPIService {
    @GET(constantString.LoginService)
    Call<LoginModel> getLoginCall(
            @QueryMap(encoded = true) Map<String, String> param);

    @GET(constantString.otpVerifyService)
    Call<otpVerificationModel> getOtpVerificationCall(
            @QueryMap(encoded = true) Map<String, String> param);

    @GET(constantString.getCarListService)
    Call<carDriverMappingModel> getcarDriverMappingCarList(@QueryMap(encoded = true) Map<String, String> param);

    @GET(constantString.getUnassigneDriverlistService)
    Call<driverListModel> getcarDriverMappingDriverList(@QueryMap(encoded = true) Map<String, String> param);

    @GET(constantString.updateCarDriverMappingService)
    Call<updateCarDriverMappingModel> updateAssignCartoDriver(@QueryMap(encoded = true) HashMap<String, String> map);

    @GET(constantString.bookCarListService)
    Call<bookedCarModel> getBookCar(@QueryMap(encoded = true) HashMap<String, String> map);

    @GET(constantString.updateTripDetailsService)
    Call<updateTripModel> updateTrip(HashMap<String, String> map);

    @GET(constantString.getCarTypeService)
    Call<searchCarTypeModel> getCarType(HashMap<String, String> map);

    @GET(constantString.searchCarService)
    Call<searchCarModel> getSearchCar(HashMap<String, String> map);

    @GET(constantString.paymentDataService)
    Call<paymentDataModel> getPaymentData(HashMap<String, String> map);

    @GET(constantString.cityListService)
    Call<cityListModel> getCityList(HashMap<String, String> map);

    @GET(constantString.bookCarService)
    Call<bookCarModel> getBookCarData(HashMap<String, String> map);

    @GET(constantString.preBookingService)
    Call<preBookingModel> preBookingData(HashMap<String, String> map);

    @GET(constantString.preBookingCarListService)
    Call<preBookCarListModel> getPreBookingCarList(HashMap<String, String> map);
}
