package com.de.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by AMD21 on 20/6/17.
 */

public class validationCheck {

    public static boolean checkEmail(String email) {

        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (email == null)
            return false;
        else if (email.matches(emailPattern))
            return true;
        else
            return false;
    }

    public static boolean dateValidation(String firstDate,String secondDate){
        try {
            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
            Date mFromDate = dateFormatter.parse(firstDate.trim().replace("/", "-"));
            Date mToDate = dateFormatter.parse(secondDate.trim().replace("/", "-"));

            if (mFromDate.compareTo(mToDate) <= 0) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
