package com.de.preBookingCar;

import android.widget.AutoCompleteTextView;
import android.widget.TextView;

import com.de.baseClass.baseDate;
import com.de.baseClass.basePresenter;
import com.de.baseClass.baseView;
import com.de.data.APIResponse;

import java.util.HashMap;

/**
 * Created by Bhadresh on 15/6/17.
 */

public interface preBookingCarContract {

    interface View extends baseView<Presenter> ,baseDate {



        void setAutomaticInvoice();

        void setManualInvoice();

        boolean checkValidation();

        void setGooglePlaceApi(AutoCompleteTextView autoCompleteTextView);

        void displayCalender(TextView textView);
    }

    interface Presenter extends basePresenter {

        void doGetCity(HashMap<String, String> map, APIResponse apiResponse);

        void doGetPaymentData(HashMap<String, String> map, APIResponse apiResponse);

        void doPreBookingCar(HashMap<String, String> map, APIResponse apiResponse);

    }
}
