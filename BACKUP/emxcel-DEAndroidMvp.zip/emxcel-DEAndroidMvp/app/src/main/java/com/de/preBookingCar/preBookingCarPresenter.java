package com.de.preBookingCar;

import com.de.data.APIResponse;
import com.de.data.DERepository;

import java.util.HashMap;

/**
 * Created by Bhadresh on 15/6/17.
 */

public class preBookingCarPresenter implements preBookingCarContract.Presenter {

    DERepository mDEDeRepository;
    preBookingCarContract.View mView;

    public preBookingCarPresenter(DERepository mDEDeRepository, preBookingCarContract.View mView) {
        this.mDEDeRepository = mDEDeRepository;
        this.mView = mView;

        mView.setPresenter(this);
    }

    @Override
    public void doGetCity(HashMap<String, String> map, APIResponse apiResponse) {

        mDEDeRepository.doGetCity(map, apiResponse);
    }

    @Override
    public void doGetPaymentData(HashMap<String, String> map, APIResponse apiResponse) {

        mDEDeRepository.doGetPaymentData(map, apiResponse);
    }

    @Override
    public void doPreBookingCar(HashMap<String, String> map, APIResponse apiResponse) {
        mDEDeRepository.doPreBookingCar(map, apiResponse);
    }


}
