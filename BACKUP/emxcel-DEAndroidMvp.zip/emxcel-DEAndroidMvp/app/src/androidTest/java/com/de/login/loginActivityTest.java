package com.de.login;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;

import com.de.R;

import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class loginActivityTest {

    @Rule
    public ActivityTestRule<loginActivity> mActivityTestRule = new ActivityTestRule<>(loginActivity.class);

    @Test
    public void loginActivityTest() {
        ViewInteraction frameLayout = onView(
                allOf(IsInstanceOf.<View>instanceOf(android.widget.FrameLayout.class), isDisplayed()));
//        frameLayout.check(matches(isDisplayed()));

        ViewInteraction appCompatEditText = onView(
                withId(R.id.et_user_contactno));
        appCompatEditText.perform(scrollTo(), click());

        ViewInteraction appCompatEditText2 = onView(
                withId(R.id.et_user_contactno));
        appCompatEditText2.perform(scrollTo(), replaceText(""), closeSoftKeyboard());


        ViewInteraction appCompatEditText3 = onView(
                withId(R.id.et_password));
        appCompatEditText3.perform(scrollTo(), replaceText(""), closeSoftKeyboard());

        ViewInteraction appCompatEditText4 = onView(
                allOf(withId(R.id.et_password), withText("")));
        appCompatEditText4.perform(pressImeActionButton());

        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.btn_login), withText("Sign In")));
        appCompatButton.perform(scrollTo(), click());

//        ViewInteraction appCompatEditText5 = onView(
//                allOf(withId(R.id.edt_verify_otp), isDisplayed()));
//        appCompatEditText5.perform(click());
//
//
//        ViewInteraction appCompatEditText6 = onView(
//                allOf(withId(R.id.edt_verify_otp), isDisplayed()));
//        appCompatEditText6.perform(click());
//
//        ViewInteraction appCompatEditText7 = onView(
//                allOf(withId(R.id.edt_verify_otp), isDisplayed()));
//        appCompatEditText7.perform(replaceText("123665"), closeSoftKeyboard());
//
//        ViewInteraction appCompatEditText8 = onView(
//                allOf(withId(R.id.edt_verify_otp), withText("123665")));
//        appCompatEditText8.perform(pressImeActionButton());
//
//        ViewInteraction appCompatButton3 = onView(
//                allOf(withId(R.id.btn_verify), withText("Verify")));
//        appCompatButton3.perform(click());
//
//        ViewInteraction appCompatImageButton = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatImageButton")),
//                        withParent(withId(R.id.toolbar)),
//                        isDisplayed()));
//        appCompatImageButton.perform(click());



    }



}
